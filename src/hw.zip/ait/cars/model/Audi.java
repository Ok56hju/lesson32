package ait.cars.model;

public class Audi extends Car{
    public Audi(String regNumber, String model, String company, double engine, String color) {
        super(regNumber, model, company, engine, color);
    }
}
