package ait.cars.model;

public class Bmw extends Car {
    public Bmw(String regNumber, String model, String company, double engine, String color) {
        super(regNumber, model, company, engine, color);
    }
}
