package ait.cars.model;

public class Honda extends Car{
    public Honda(String regNumber, String model, String company, double engine, String color) {
        super(regNumber, model, company, engine, color);
    }
}
