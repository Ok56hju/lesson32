package ait.cars.test;

import ait.cars.dao.Garage;
import ait.cars.dao.GarageImpl;
import ait.cars.model.Audi;
import ait.cars.model.Bmw;
import ait.cars.model.Car;
import ait.cars.model.Honda;

import static org.junit.jupiter.api.Assertions.*;

class GarageImplTest {
    Garage garage;
    Car[] avto;

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        garage = new GarageImpl(5);
        avto = new Car[4];
        avto[0] = new Bmw("ZN6798", "X5", "BMW", 2890, "RED");
        avto[1] = new Audi("VF6785", "A8", "Audi", 3000, "black");
        avto[2] = new Honda("WN8765", "civic", "Honda", 1978, "blau");
        for (int i = 0; i < avto.length; i++) {
            garage.addCar(avto[i]);

        }

    }

    @org.junit.jupiter.api.Test
    void addCar() {
        assertFalse(garage.addCar(null));
        assertFalse(garage.addCar(avto[1]));
        Car car = new Audi("VF6788", "X5", "BMW", 2890, "RED");
        assertTrue(garage.addCar(car));
//        assertEquals(5, garage.size);
        car = new Audi("VF6787", "X5", "BMW", 2890, "RED");
        assertFalse(garage.addCar(car));
    }

    @org.junit.jupiter.api.Test
    void removeCar() {
        Car car = garage.removeCar("WN8765");
        assertEquals(avto[2],car);
//        assertEquals();
        assertNull(garage.removeCar("WN8765"));
    }

    @org.junit.jupiter.api.Test
    void findCarsByRegNumer() {
    }

    @org.junit.jupiter.api.Test
    void findCarsByModel() {
    }

    @org.junit.jupiter.api.Test
    void findCarsByCompany() {
    }

    @org.junit.jupiter.api.Test
    void findCarsByEngine() {
    }

    @org.junit.jupiter.api.Test
    void findCarsByColors() {
    }
}